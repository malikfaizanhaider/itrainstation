import {Component, OnInit} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
import {DatePipe} from '@angular/common';
import {FormControl, FormGroup} from '@angular/forms';

export interface PeriodicElement {
  name: string;
  lname: string;
  position: number;
  weight: number;
  symbol: string;
  DOB: Date;
  created: Date;
}


const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, lname: '1212', name: 'Hydrogen', weight: 1.0079, symbol: 'H', DOB: new Date(2016, 11, 24), created: new Date(2015, 15, 24)},
  {position: 2, lname: '1212', name: 'Helium', weight: 4.0026, symbol: 'He', DOB: new Date(2018, 18, 24), created: new Date(2018, 11, 24)},
  {position: 3, lname: '1212', name: 'Lithium', weight: 6.941, symbol: 'Li', DOB: new Date(1993, 6, 12), created: new Date(1999, 12, 15)},
  {position: 4, lname: '1212', name: 'Beryllium', weight: 9.0122, symbol: 'Be', DOB: new Date(2001, 7, 6), created: new Date(2011, 10, 6)},
  {position: 5, lname: '1212', name: 'Boron', weight: 10.811, symbol: 'B', DOB: new Date(2020, 5, 9), created: new Date(2020, 5, 9)},
  {position: 6, lname: '1212', name: 'Carbon', weight: 12.0107, symbol: 'C', DOB: new Date(2008, 7, 14), created: new Date(2008, 7, 14)},
  {position: 7, lname: '1212', name: 'Nitrogen', weight: 14.0067, symbol: 'N', DOB: new Date(1998, 11, 18), created: new Date(1998, 11, 18)},
  {position: 8, lname: '1212', name: 'Oxygen', weight: 15.9994, symbol: 'O', DOB: new Date(2002, 2, 24), created: new Date(2002, 2, 24)},
  {position: 9, lname: '1212', name: 'Fluorine', weight: 18.9984, symbol: 'F', DOB: new Date(2006, 4, 29), created: new Date(2006, 4, 29)},
  {position: 10, lname: '1212', name: 'Neon', weight: 20.1797, symbol: 'Ne', DOB: new Date(2040, 5, 30), created: new Date(2040, 5, 30)},
];

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent {
  displayedColumns: string[] = ['position', 'name', 'lname', 'weight', 'symbol', 'DOB', 'founded'];
  displayedColumnsNames: string[] = ['No.', 'Name', 'Last Name', 'Weight', 'Symbol', 'DOB', 'Founded'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  pipe: DatePipe;

  filterForm = new FormGroup({
    fromDate: new FormControl(),
    toDate: new FormControl(),
  });

  get fromDate() {
    return this.filterForm.get('fromDate').value;
  }

  get toDate() {
    return this.filterForm.get('toDate').value;
  }

  constructor() {
    this.pipe = new DatePipe('en');
    this.dataSource.filterPredicate = (data, filter) => {
      if (this.fromDate && this.toDate) {
        return data.created >= this.fromDate && data.created <= this.toDate;
      }
      return true;
    };
  }

  applyFilter() {
    this.dataSource.filter = '' + Math.random();
  }
}
