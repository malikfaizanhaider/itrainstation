import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { MaterialModule } from './material/material.module';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppComponent } from './app.component';
import { TableComponent } from './table/table.component';
import { VaMatTableComponent } from './table/va-mat-table/va-mat-table.component';
import { ColumnSorterComponent } from './table/va-mat-table/actions/column-sorter/column-sorter.component';

@NgModule({
  declarations: [
    AppComponent,
    TableComponent,
    VaMatTableComponent,
    ColumnSorterComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    FlexLayoutModule,
    MaterialModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
